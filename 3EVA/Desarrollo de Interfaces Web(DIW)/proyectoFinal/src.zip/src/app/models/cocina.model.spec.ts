import { Cocina } from './cocina.model';

describe('Cocina', () => {
  it('should create an instance', () => {
    expect(new Cocina()).toBeTruthy();
  });
});
